const mysql = require('mysql');
const express = require('express');
const req = require('express/lib/request');
const res = require('express/lib/response');
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'dbkurenkoitbook'
});
const app=  express();
app.use(express.json());

connection.connect((err) => {
  if (err) throw err;
  console.log('Подключено к базе данных!');


});


app.get('/', (req, res) => {
    connection.query('SELECT * FROM books', (err, result) => {
        if (err) throw err;
        console.log(result);
        res.json(result)
      });
  });

app.get('/book/:id', (req, res) => {
  const id = req.params.id;
  const sql = `SELECT * FROM books INNER JOIN bookauthor ON books.id = bookauthor.bookId WHERE bookauthor.idcat = '${id}'`
    connection.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.json(result);
      });
});

app.get('/authors/:authors', (req, res) => {
  const authors = req.params.authors;
  const sql = `SELECT * FROM books INNER JOIN bookauthor ON books.id = bookauthor.bookId JOIN authors ON authors.id = bookauthor.authorId WHERE authors.id = '${authors}'`; 
  connection.query( sql, (err, result) => {
        if (err) throw err;
        console.log(result);
        res.json(result);
      });
});

app.post('/newbook', (req, res) => {
  const {name} = req.body;
  const sql = `INSERT INTO books (name) VALUES (?)`;
  connection.query(sql, name, (err, result) => {
    if (err) throw err;
    console.log(sql);
    res.send('New book added to database!' + result);
  });
});

app.delete('/book/:id', (req,res) => {
  const {id} = req.params;
  const sql = `DELETE FROM books WHERE id = '${id}'`
  connection.query(sql, id, (err, results) => {
    if (err) throw err;
    console.log(results);
    res.send(' book deleted from database!');
  });
});

app.listen(3001, ()=> {
    console.log('Start!');
})